# 시스템 아키텍처

## 전체 구조도

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          INTERNET / CLIENTS                             │
│              Browser · Mobile · Third-party Webhooks                    │
└──────────────────────────┬──────────────────────────────────────────────┘
                           │ HTTPS
┌──────────────────────────▼──────────────────────────────────────────────┐
│                      NEXT.JS APP (Vercel / Docker)                      │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │  App Router  (src/app/)                                         │    │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────────┐  │    │
│  │  │ /auth    │ │/dashboard│ │/workflows│ │  /api/v1 (REST)  │  │    │
│  │  │ /login   │ │ /files   │ │ /rules   │ │  rate-limited    │  │    │
│  │  │ /signup  │ │ /jobs    │ │/approvals│ │  plan-enforced   │  │    │
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────────────┘  │    │
│  └─────────────────────────────────────────────────────────────────┘    │
└──────┬────────────────────┬────────────────────────┬────────────────────┘
       │                    │                        │
┌──────▼──────┐   ┌─────────▼──────────┐   ┌───────▼──────────────────┐
│  PostgreSQL  │   │   Redis (BullMQ)   │   │  Dropbox API v2          │
│  (Prisma)    │   │   ┌─────────────┐  │   │  api.dropboxapi.com      │
│              │   │   │  rule-exec  │  │   │                          │
│  - Users     │   │   │  file-watch │  │   │  OAuth 2.0 PKCE          │
│  - Orgs      │   │   │  scheduler  │  │   │  /files/list_folder      │
│  - Tokens    │   │   │  notifier   │  │   │  /files/move_v2          │
│  - Workflows │   │   └─────────────┘  │   │  /files/copy_v2          │
│  - AuditLogs │   └────────────────────┘   └──────────────────────────┘
│  - Snapshots │            │
└─────────────┘   ┌─────────▼──────────────────────────────────────┐
                  │  WORKER SERVICE (Node.js / Docker sidecar)     │
                  │  ┌───────────────┐  ┌─────────────────────────┐│
                  │  │ Rule Executor │  │  Scheduler / Cron       ││
                  │  │ - match files │  │  - cleanup jobs         ││
                  │  │ - run actions │  │  - token refresh        ││
                  │  │ - undo/snap   │  │  - usage reset          ││
                  │  └───────────────┘  └─────────────────────────┘│
                  │  ┌───────────────┐  ┌─────────────────────────┐│
                  │  │ Folder Watcher│  │  Notifier               ││
                  │  │ - poll/webhook│  │  - Slack                ││
                  │  │ - detect diff │  │  - Email (Resend)       ││
                  │  │ - trigger rule│  │  - Kakao 알림톡          ││
                  │  └───────────────┘  └─────────────────────────┘│
                  └────────────────────────────────────────────────┘
```

---

## 멀티테넌트 설계

Mydropbox는 **행 수준(Row-Level) 멀티테넌시**를 구현합니다.
모든 DB 레코드는 `orgId`를 가지며, API 미들웨어가 매 요청마다 테넌트 컨텍스트를 강제합니다.

```
Organization (테넌트)
    ├── User → Membership (역할: OWNER / ADMIN / MEMBER / VIEWER)
    ├── DropboxConnection (여러 계정 연결 가능)
    ├── Workflow → Rule → Trigger
    ├── Job → Snapshot (Undo 지원)
    └── AuditLog
```

!!! info "테넌트 격리 원칙"
    - `orgId`는 항상 세션에서 추출 (요청 바디에서 신뢰하지 않음)
    - 모든 DB 쿼리에 `WHERE orgId = ?` 강제 적용
    - Stripe Customer는 Organization과 1:1 매핑

---

## 배포 아키텍처

```yaml
# docker-compose.yml 구조
services:
  app:      # Next.js 앱 (포트 3000)
  worker:   # BullMQ 워커 (백그라운드)
  postgres: # PostgreSQL 16
  redis:    # Redis 7 (큐 + 캐시)
```

### 클라우드 배포 옵션

| 옵션 | 앱 | DB | Redis |
|------|----|----|-------|
| AWS | ECS Fargate | RDS PostgreSQL | ElastiCache |
| GCP | Cloud Run | Cloud SQL | Memorystore |
| Railway | Railway | Railway PostgreSQL | Railway Redis |
| Vercel + | Vercel | Supabase | Upstash |
