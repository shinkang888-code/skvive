# Mydropbox 문서에 오신 것을 환영합니다

**Mydropbox**는 Dropbox 파일 자동화를 위한 멀티테넌트 SaaS 플랫폼입니다.

---

## 🚀 주요 기능

=== "파일 자동화"
    - PDF → `/Docs/PDF/{YYYY}/{MM}` 자동 분류
    - 인보이스 파일 → `/Finance/Invoices/` 자동 이동
    - 스크린샷 → `/Images/Screenshots/` 자동 정리
    - 파일명 패턴 일괄 변경

=== "워크플로우 엔진"
    - JSON Rule DSL 기반 자동화 규칙
    - 이벤트 / 스케줄 / 수동 트리거
    - 승인 워크플로우 (ToReview → Approved/Rejected)
    - 실행 전 스냅샷 & 원클릭 Undo

=== "알림 & 모니터링"
    - Slack / 이메일 / Kakao 알림톡 연동
    - 폴더 변경 실시간 감지
    - 완전한 감사 로그 (Audit Log)
    - CSV 내보내기

---

## 🏗 기술 스택

| 레이어 | 기술 |
|--------|------|
| Frontend | Next.js 14 (App Router) + TypeScript |
| Backend | Next.js API Routes |
| Database | PostgreSQL + Prisma ORM |
| Auth | NextAuth.js |
| Queue | BullMQ + Redis |
| Payments | Stripe Subscriptions |
| Dropbox | OAuth 2.0 PKCE + Auto Refresh |
| Deploy | Docker + GitHub Actions |

---

## 📐 문서 구조

- [**시스템 아키텍처**](architecture.md) — 전체 시스템 구조도 및 멀티테넌트 설계
- [**데이터베이스 스키마**](database-schema.md) — Prisma 전체 모델
- [**API 설계**](api-design.md) — REST 엔드포인트 & 페이로드
- [**Dropbox 연동**](dropbox-integration.md) — OAuth, 토큰 암호화, 자동 갱신
- [**워크플로우 엔진**](workflow-engine.md) — Rule DSL, 실행 엔진, Undo
- [**보안**](security.md) — 보안 체크리스트 18개 항목
- [**빌링 & 플랜**](billing.md) — Stripe 연동 및 플랜 비교
- [**구현 계획**](implementation-plan.md) — 12주 마일스톤

---

## ⚡ 빠른 시작

```bash
git clone https://github.com/yourname/mydropbox
cd mydropbox
cp .env.example .env
docker-compose up -d
npx prisma migrate dev
npm run dev
```

!!! tip "로컬 개발 환경"
    `.env.example`에서 `DROPBOX_APP_KEY`, `DROPBOX_APP_SECRET`,
    `TOKEN_ENCRYPTION_KEY`를 먼저 설정하세요.
