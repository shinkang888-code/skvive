# 보안

## 보안 체크리스트

### 토큰 보안

| 항목 | 구현 방법 |
|------|----------|
| ✅ AES-256-GCM 암호화 | `encryptToken()` — 토큰마다 랜덤 IV 사용 |
| ✅ 평문 로그 금지 | 토큰은 절대 로그에 출력하지 않음. ID만 참조 |
| ✅ 마스터 키 환경변수 | `TOKEN_ENCRYPTION_KEY` — 환경변수 또는 AWS Secrets Manager |
| ✅ 키 로테이션 | 재암호화 잡으로 주기적 키 교체 가능 |

### OAuth & API 보안

| 항목 | 구현 방법 |
|------|----------|
| ✅ PKCE 코드 챌린지 | 모든 OAuth 흐름에 SHA-256 code_challenge 적용 |
| ✅ State 파라미터 | 세션에 저장 후 콜백에서 검증 (CSRF 방지) |
| ✅ 최소 권한 스코프 | 5개 스코프만 요청 (필요한 것만) |
| ✅ JWT HttpOnly 쿠키 | `Secure; SameSite=Strict; HttpOnly` |
| ✅ 플랜별 Rate Limit | Free: 100 req/hr, Pro: 1000, Team: 5000 |

### 멀티테넌시 격리

| 항목 | 구현 방법 |
|------|----------|
| ✅ 테넌트 강제 격리 | `orgId`는 항상 세션에서 추출, 요청 바디 신뢰 안 함 |
| ✅ 역할 기반 접근 제어 | OWNER / ADMIN / MEMBER / VIEWER |
| ✅ 모든 쿼리에 orgId | Prisma 미들웨어로 자동 필터 적용 |

### 웹훅 보안

| 항목 | 구현 방법 |
|------|----------|
| ✅ Stripe 서명 검증 | `stripe.webhooks.constructEvent()` |
| ✅ Dropbox 서명 검증 | `X-Dropbox-Signature` HMAC-SHA256 검증 |

### 인프라 보안

| 항목 | 구현 방법 |
|------|----------|
| ✅ SSRF 방지 | Dropbox API URL 허용 목록만 사용 |
| ✅ XSS 방지 | CSP 헤더 설정 (`next.config.js`) |
| ✅ SQL 인젝션 방지 | Prisma ORM 파라미터화 쿼리 |
| ✅ Non-root Docker | `USER node` Dockerfile 지시어 |
| ✅ 감사 로그 | 모든 파일 작업 전/후 AuditLog 생성 |

---

## CSP 헤더 설정

```javascript
// next.config.js
const securityHeaders = [
  {
    key: 'Content-Security-Policy',
    value: [
      "default-src 'self'",
      "script-src 'self' 'unsafe-eval' 'unsafe-inline'",
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: https:",
      "connect-src 'self' https://api.dropboxapi.com",
      "frame-ancestors 'none'",
    ].join('; ')
  },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
];
```

---

## 감사 로그 구조

모든 파일 작업은 `AuditLog` 테이블에 기록됩니다.

```json
{
  "orgId": "org_123",
  "actor": "user_456",
  "action": "file.move",
  "resource": "/Downloads/report.pdf",
  "metadata": {
    "destination": "/Docs/PDF/2025/01/report.pdf",
    "ruleId": "rule_789",
    "jobId": "job_abc"
  },
  "ipAddress": "1.2.3.4",
  "createdAt": "2025-01-15T10:30:00Z"
}
```

!!! tip "Team 플랜 — CSV 내보내기"
    `GET /api/v1/audit-logs?format=csv&from=2025-01-01&to=2025-01-31`
    로 기간별 감사 로그를 CSV로 내보낼 수 있습니다.
