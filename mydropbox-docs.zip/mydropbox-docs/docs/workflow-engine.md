# 워크플로우 엔진

## Rule DSL 구조

규칙은 JSON 형식으로 저장됩니다. `conditions`와 `actions`로 구성됩니다.

```typescript
interface RuleDefinition {
  conditions: Condition[];
  conditionLogic: 'AND' | 'OR';
  actions: Action[];
  onConflict: 'overwrite' | 'version' | 'skip';
  normalizeFilename?: boolean;
  takeSnapshot: boolean;       // 항상 true 권장
  maxFilesPerRun?: number;     // 기본값 100
}

interface Condition {
  field: 'path' | 'name' | 'extension' | 'size' | 'modified' | 'mimeType';
  op: 'eq' | 'neq' | 'startsWith' | 'endsWith' | 'contains'
    | 'regex' | 'gt' | 'lt' | 'olderThanDays';
  value: string | number;
}

interface Action {
  type: 'move' | 'copy' | 'rename' | 'delete' | 'createFolder' | 'notify';
  destination?: string;   // 경로 템플릿 지원
  pattern?: string;       // 이름 변경 패턴
  channel?: 'slack' | 'email' | 'kakao';
}
```

---

## 규칙 예시

=== "PDF 자동 분류"
    ```json
    {
      "conditions": [
        { "field": "path", "op": "startsWith", "value": "/Downloads" },
        { "field": "extension", "op": "eq", "value": "pdf" }
      ],
      "conditionLogic": "AND",
      "actions": [
        { "type": "move", "destination": "/Docs/PDF/{YYYY}/{MM}" }
      ],
      "onConflict": "version",
      "takeSnapshot": true
    }
    ```

=== "인보이스 분류"
    ```json
    {
      "conditions": [
        { "field": "name", "op": "contains", "value": "invoice" },
        { "field": "extension", "op": "eq", "value": "xlsx" }
      ],
      "conditionLogic": "AND",
      "actions": [
        { "type": "move", "destination": "/Finance/Invoices/{YYYY}" }
      ],
      "onConflict": "version",
      "takeSnapshot": true
    }
    ```

=== "임시파일 정리"
    ```json
    {
      "conditions": [
        { "field": "path", "op": "startsWith", "value": "/Temp" },
        { "field": "modified", "op": "olderThanDays", "value": 30 }
      ],
      "conditionLogic": "AND",
      "actions": [
        { "type": "move", "destination": "/Archive/Trash/{YYYY}-{MM}-{DD}" }
      ],
      "onConflict": "skip",
      "takeSnapshot": true
    }
    ```

=== "일괄 이름 변경"
    ```json
    {
      "conditions": [
        { "field": "path", "op": "startsWith", "value": "/Projects/Alpha" }
      ],
      "conditionLogic": "AND",
      "actions": [
        {
          "type": "rename",
          "pattern": "Alpha_{YYYYMMDD}_{NAME}"
        }
      ],
      "onConflict": "skip",
      "takeSnapshot": true
    }
    ```

---

## 트리거 유형

| 유형 | 설정 | 동작 |
|------|------|------|
| `EVENT` | `{ "folderPath": "/Downloads" }` | 폴더 변경 시 즉시 실행 |
| `SCHEDULE` | `{ "cron": "0 2 * * *" }` | 매일 오전 2시 실행 |
| `MANUAL` | `{}` | API 호출로 수동 실행 |
| `WEBHOOK` | `{ "secret": "..." }` | 외부 웹훅으로 트리거 |

---

## 승인 워크플로우

```
파일이 /Shared/ToReview 에 업로드
              ↓
    ApprovalRequest 생성
              ↓
    Admin에게 알림 발송 (Slack/Email)
              ↓
        Admin 검토
       ↙         ↘
   승인 (Approve)  거절 (Reject)
      ↓                ↓
/Shared/Approved  /Shared/Rejected
                  + 거절 사유 저장
```

---

## Undo / 롤백

모든 파일 작업 전 **Snapshot**이 자동 생성됩니다.

```
Job 실행
  ├── Snapshot 생성 (beforeState: 원본 경로/정보)
  ├── 파일 작업 수행
  └── Snapshot 업데이트 (afterState: 이동 후 경로)

POST /jobs/:id/undo
  ├── Snapshot 역순으로 조회
  ├── afterState → beforeState 로 파일 복원
  └── Snapshot.undone = true 표시
```

!!! info "Undo 가능 조건"
    - Pro 플랜 이상
    - 작업 완료 후 30일 이내
    - 파일이 이후에 삭제되지 않은 경우

---

## 멱등성 (Idempotency) 전략

동일한 파일을 중복 처리하지 않기 위해:

1. 작업 전 `Snapshot` 테이블에서 동일 파일 + 동일 목적지 이미 처리 여부 확인
2. BullMQ Job ID를 `규칙ID + 파일경로 + 날짜`의 해시로 생성
3. 이미 완료된 Job은 `COMPLETED` 상태로 조기 반환
