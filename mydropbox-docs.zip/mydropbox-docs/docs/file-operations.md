# 파일 오퍼레이션

## 지원 기능

| 기능 | Dropbox API | 설명 |
|------|-------------|------|
| 파일 검색 | `/files/search_v2` | 파일명/내용 검색 |
| 폴더 생성 | `/files/create_folder_v2` | 중첩 경로 자동 생성 |
| 파일/폴더 이동 | `/files/move_v2` | 충돌 옵션 지원 |
| 파일/폴더 이름 변경 | `/files/move_v2` (같은 경로) | rename = move |
| 폴더 목록 조회 | `/files/list_folder` | 커서 기반 페이지네이션 |
| 변경 감지 | `/files/list_folder/longpoll` | 실시간 폴더 감시 |

---

## 파일 오퍼레이션 래퍼

```typescript
// src/lib/dropbox/files.ts

// 파일 검색
export async function searchFiles(connectionId: string, query: string) {
  return dbxRequest(connectionId, '/files/search_v2', {
    query,
    options: { max_results: 50, file_status: 'active' }
  });
}

// 폴더 생성
export async function createFolder(connectionId: string, path: string) {
  return dbxRequest(connectionId, '/files/create_folder_v2', {
    path,
    autorename: false
  });
}

// 파일 이동 (충돌 옵션: rename | overwrite)
export async function moveFile(
  connectionId: string,
  fromPath: string,
  toPath: string,
  onConflict: 'rename' | 'overwrite' = 'rename'
) {
  return dbxRequest(connectionId, '/files/move_v2', {
    from_path: fromPath,
    to_path: toPath,
    autorename: onConflict === 'rename'
  });
}

// 이름 변경 (= 같은 폴더 내 이동)
export async function renameFile(
  connectionId: string,
  path: string,
  newName: string
) {
  const parts = path.split('/');
  parts[parts.length - 1] = newName;
  return moveFile(connectionId, path, parts.join('/'));
}
```

---

## 충돌 처리 전략

| 전략 | 설명 | 예시 |
|------|------|------|
| `overwrite` | 기존 파일 덮어쓰기 | `report.pdf` → `report.pdf` |
| `version` | 버전 번호 추가 | `report.pdf` → `report_v2.pdf` |
| `skip` | 이미 있으면 건너뜀 | 변경 없음 |

---

## 파일명 정규화

`normalizeFilename: true` 설정 시 적용되는 규칙:

- 특수문자 제거 (`!@#$%^&*` 등)
- 공백 → 언더스코어
- 한글 유지
- 확장자 소문자 통일

```
"My Report (Final) v2!.PDF"
        ↓
"My_Report_Final_v2.pdf"
```

---

## 경로 템플릿 토큰

| 토큰 | 설명 | 예시 |
|------|------|------|
| `{YYYY}` | 4자리 연도 | `2025` |
| `{MM}` | 2자리 월 | `01` |
| `{DD}` | 2자리 일 | `15` |
| `{NAME}` | 원본 파일명 (확장자 제외) | `report` |
| `{EXT}` | 파일 확장자 | `pdf` |
| `{project}` | 규칙에서 지정한 변수 | `MyProject` |

**예시:**
```
destination: "/Docs/{EXT}/{YYYY}/{MM}/{NAME}.{EXT}"
결과: "/Docs/pdf/2025/01/report.pdf"
```
