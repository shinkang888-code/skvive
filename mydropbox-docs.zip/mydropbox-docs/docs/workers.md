# 백그라운드 워커

## 큐 구성

| 큐 이름 | 동시 실행 | 역할 |
|---------|----------|------|
| `rule-execution` | 5 | 워크플로우 규칙 실행 |
| `file-watcher` | 10 | Dropbox 폴더 변경 감지 |
| `scheduler` | 1 | 스케줄 트리거, 정리 작업 |
| `notifier` | 3 | Slack/Email/Kakao 알림 발송 |
| `approval-check` | 2 | 승인 요청 타임아웃 체크 |

---

## 폴더 감시 전략

### Webhook 방식 (권장)

```
Dropbox가 변경 감지
        ↓
POST /webhooks/dropbox 호출
        ↓
서명 검증 (HMAC-SHA256)
        ↓
file-watcher 큐에 Job 추가
        ↓
/files/list_folder/continue 로 변경 목록 조회
        ↓
매칭되는 Rule 실행
```

### Longpoll 방식 (폴백)

```
Worker → notify.dropboxapi.com/2/files/list_folder/longpoll
  timeout: 30초
    ↓ (변경 있을 때)
  changes: true
    ↓
/files/list_folder/continue 로 실제 변경 조회
    ↓
Rule 매칭 및 실행
```

---

## 스케줄러 Cron 작업

```typescript
// 매 분: 스케줄 트리거 확인
'* * * * *'    → check-scheduled-triggers

// 30분마다: 만료 임박 토큰 갱신
'*/30 * * * *' → refresh-expiring-tokens

// 매일 오전 3시: 임시파일 정리
'0 3 * * *'    → cleanup-temp-files

// 매월 1일: 사용량 미터 초기화
'0 0 1 * *'    → reset-usage-meters
```

---

## 실패 처리 & 재시도

```typescript
const defaultJobOptions = {
  attempts: 3,
  backoff: {
    type: 'exponential',
    delay: 2000,  // 2초, 4초, 8초
  },
  removeOnComplete: 100,  // 완료된 Job 최대 100개 보관
  removeOnFail: 50,       // 실패한 Job 최대 50개 보관
};
```

!!! warning "Dead Letter Queue"
    3회 재시도 후에도 실패한 Job은 `failed` 상태로 보관됩니다.
    관리자 대시보드에서 수동 재시도 또는 취소할 수 있습니다.

---

## 알림 채널

=== "Slack"
    ```typescript
    await fetch(process.env.SLACK_WEBHOOK_URL!, {
      method: 'POST',
      body: JSON.stringify({
        text: `📁 파일 이동 완료: ${fileName}`,
        blocks: [...]
      })
    });
    ```

=== "Email (Resend)"
    ```typescript
    await resend.emails.send({
      from: 'noreply@mydropbox.io',
      to: userEmail,
      subject: '[Mydropbox] 파일 처리 완료',
      html: emailTemplate(data)
    });
    ```

=== "Kakao 알림톡"
    ```typescript
    await fetch('https://kapi.kakao.com/v2/api/talk/memo/default/send', {
      method: 'POST',
      headers: { Authorization: `Bearer ${kakaoToken}` },
      body: JSON.stringify({ template_object: { ... } })
    });
    ```
