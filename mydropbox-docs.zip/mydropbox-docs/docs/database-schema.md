# 데이터베이스 스키마

## Prisma 전체 모델

### 테넌트 / 인증

```prisma
model Organization {
  id               String   @id @default(cuid())
  name             String
  slug             String   @unique
  plan             PlanType @default(FREE)
  stripeCustomerId String?  @unique
  createdAt        DateTime @default(now())
  updatedAt        DateTime @updatedAt

  memberships  Membership[]
  dropboxConns DropboxConnection[]
  workflows    Workflow[]
  jobs         Job[]
  auditLogs    AuditLog[]
  subscription Subscription?
  usageMeter   UsageMeter?
}

model User {
  id             String   @id @default(cuid())
  email          String   @unique
  name           String?
  hashedPassword String?
  emailVerified  Boolean  @default(false)
  createdAt      DateTime @default(now())

  memberships Membership[]
  sessions    Session[]
  approvals   ApprovalAction[]
}

model Membership {
  id       String  @id @default(cuid())
  role     OrgRole @default(MEMBER)
  userId   String
  orgId    String
  joinedAt DateTime @default(now())

  user User         @relation(fields: [userId], references: [id], onDelete: Cascade)
  org  Organization @relation(fields: [orgId],  references: [id], onDelete: Cascade)

  @@unique([userId, orgId])
}
```

### Dropbox 연결 (토큰 암호화)

```prisma
model DropboxConnection {
  id                    String             @id @default(cuid())
  orgId                 String
  label                 String             @default("My Dropbox")
  accountType           DropboxAccountType @default(PERSONAL)
  dropboxAccountId      String
  dropboxEmail          String?
  encryptedRefreshToken String             // AES-256-GCM 암호화
  encryptedAccessToken  String?            // 캐시용, AES-256-GCM
  accessTokenExpiresAt  DateTime?
  scopes                String[]
  isActive              Boolean            @default(true)
  createdAt             DateTime           @default(now())
  updatedAt             DateTime           @updatedAt

  org       Organization    @relation(fields: [orgId], references: [id])
  workflows Workflow[]
  watchers  FolderWatcher[]

  @@unique([orgId, dropboxAccountId])
}
```

!!! warning "보안 주의사항"
    `encryptedRefreshToken`과 `encryptedAccessToken`은 절대 평문으로 저장하지 않습니다.
    암호화 방식: AES-256-GCM with random IV per token.
    마스터 키는 환경변수 `TOKEN_ENCRYPTION_KEY`로 관리합니다.

### 워크플로우 & 규칙

```prisma
model Workflow {
  id           String   @id @default(cuid())
  orgId        String
  connectionId String
  name         String
  isActive     Boolean  @default(true)
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  rules    Rule[]
  triggers Trigger[]
  jobs     Job[]
}

model Rule {
  id         String   @id @default(cuid())
  workflowId String
  name       String
  priority   Int      @default(0)
  isActive   Boolean  @default(true)
  definition Json     // Rule DSL JSON
  createdAt  DateTime @default(now())
}

model Trigger {
  id         String      @id @default(cuid())
  workflowId String
  type       TriggerType // EVENT | SCHEDULE | MANUAL | WEBHOOK
  config     Json
  isActive   Boolean     @default(true)
  lastFiredAt DateTime?
}
```

### 작업 & 스냅샷

```prisma
model Job {
  id          String    @id @default(cuid())
  orgId       String
  workflowId  String?
  ruleId      String?
  type        JobType
  status      JobStatus @default(PENDING)
  payload     Json
  result      Json?
  errorMsg    String?
  retryCount  Int       @default(0)
  scheduledAt DateTime?
  startedAt   DateTime?
  completedAt DateTime?
  createdAt   DateTime  @default(now())

  snapshots Snapshot[]
  auditLogs AuditLog[]
}

model Snapshot {
  id          String   @id @default(cuid())
  jobId       String
  filePath    String
  fileRevId   String?  // Dropbox rev ID (작업 전)
  action      String   // "move" | "rename" | "delete"
  beforeState Json     // { path, name, rev, size }
  afterState  Json?
  undone      Boolean  @default(false)
  undoneAt    DateTime?
  createdAt   DateTime @default(now())
}
```

### Enum 목록

```prisma
enum PlanType   { FREE PRO TEAM ENTERPRISE }
enum OrgRole    { OWNER ADMIN MEMBER VIEWER }
enum TriggerType { EVENT SCHEDULE MANUAL WEBHOOK }
enum JobType    { RULE_EXECUTION BULK_RENAME BULK_MOVE FOLDER_CREATE CLEANUP }
enum JobStatus  { PENDING RUNNING COMPLETED FAILED CANCELLED }
enum ApprovalStatus { PENDING APPROVED REJECTED }
```

---

## ERD 관계 요약

```
Organization ──< Membership >── User
Organization ──< DropboxConnection
Organization ──< Workflow ──< Rule
                          ──< Trigger
Organization ──< Job ──< Snapshot
                     ──< AuditLog
Organization ── Subscription
Organization ── UsageMeter
```
