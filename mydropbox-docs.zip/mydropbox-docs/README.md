# Mydropbox

> Dropbox 파일 자동화 SaaS — Multi-tenant · Workflow Engine · Stripe Billing

[![Deploy Docs](https://github.com/yourname/mydropbox/actions/workflows/deploy-docs.yml/badge.svg)](https://github.com/yourname/mydropbox/actions/workflows/deploy-docs.yml)

## 📚 문서

👉 **[docs.mydropbox.io](https://yourname.github.io/mydropbox)**

| 문서 | 설명 |
|------|------|
| [시스템 아키텍처](docs/architecture.md) | 전체 구조도 및 멀티테넌트 설계 |
| [데이터베이스 스키마](docs/database-schema.md) | Prisma 전체 모델 |
| [API 설계](docs/api-design.md) | REST 엔드포인트 & 페이로드 |
| [Dropbox 연동](docs/dropbox-integration.md) | OAuth, 토큰 암호화, 자동 갱신 |
| [워크플로우 엔진](docs/workflow-engine.md) | Rule DSL, 실행 엔진, Undo |
| [보안](docs/security.md) | 보안 체크리스트 |
| [빌링 & 플랜](docs/billing.md) | Stripe 연동 및 플랜 비교 |
| [구현 계획](docs/implementation-plan.md) | 12주 마일스톤 |

## 🛠 기술 스택

- **Frontend**: Next.js 14 (App Router) + TypeScript
- **Database**: PostgreSQL + Prisma ORM
- **Queue**: BullMQ + Redis
- **Auth**: NextAuth.js
- **Payments**: Stripe
- **Deploy**: Docker + GitHub Actions
