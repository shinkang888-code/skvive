# API 설계

## 기본 정보

- **Base URL**: `https://app.mydropbox.io/api/v1`
- **인증**: `Authorization: Bearer <JWT>` 헤더
- **응답 형식**: JSON
- **에러 형식**: `{ "error": "메시지", "code": "ERROR_CODE" }`

---

## 엔드포인트 목록

### 인증

| Method | Endpoint | 설명 |
|--------|----------|------|
| `POST` | `/auth/signup` | 회원가입 + 조직 생성 |
| `POST` | `/auth/login` | 로그인, JWT 반환 |
| `POST` | `/auth/logout` | 세션 무효화 |
| `GET`  | `/auth/dropbox/connect` | Dropbox OAuth 시작 |
| `GET`  | `/auth/dropbox/callback` | OAuth 콜백 처리 |

### Dropbox 연결

| Method | Endpoint | 설명 | 플랜 |
|--------|----------|------|------|
| `GET`    | `/connections` | 연결 목록 조회 | All |
| `PATCH`  | `/connections/:id` | 라벨 수정 | All |
| `DELETE` | `/connections/:id` | 연결 해제 | All |

### 파일 조작

| Method | Endpoint | 설명 | 플랜 |
|--------|----------|------|------|
| `GET`  | `/files/search?q=` | 파일 검색 | All |
| `POST` | `/files/folder` | 폴더 생성 | All |
| `PATCH`| `/files/rename` | 파일/폴더 이름 변경 | All |
| `POST` | `/files/move` | 파일/폴더 이동 | All |

### 워크플로우

| Method | Endpoint | 설명 | 플랜 |
|--------|----------|------|------|
| `GET`    | `/workflows` | 목록 조회 | All |
| `POST`   | `/workflows` | 워크플로우 생성 | Pro+ |
| `PUT`    | `/workflows/:id` | 수정 | Pro+ |
| `DELETE` | `/workflows/:id` | 삭제 | Pro+ |
| `POST`   | `/workflows/:id/run` | 수동 실행 | Pro+ |

### 작업 & Undo

| Method | Endpoint | 설명 | 플랜 |
|--------|----------|------|------|
| `GET`  | `/jobs` | 작업 목록 (필터 가능) | All |
| `GET`  | `/jobs/:id` | 작업 상세 + 스냅샷 | All |
| `POST` | `/jobs/:id/undo` | 작업 롤백 | Pro+ |

### 승인 워크플로우

| Method | Endpoint | 설명 | 플랜 |
|--------|----------|------|------|
| `GET`  | `/approvals` | 승인 요청 목록 | Team+ |
| `POST` | `/approvals/:id/approve` | 승인 | Team+ |
| `POST` | `/approvals/:id/reject` | 거절 + 사유 | Team+ |

### 감사 로그 & 빌링

| Method | Endpoint | 설명 | 플랜 |
|--------|----------|------|------|
| `GET`  | `/audit-logs` | 감사 로그 (CSV 내보내기) | Team+ |
| `POST` | `/billing/subscribe` | Stripe 구독 생성 | All |
| `POST` | `/billing/portal` | Stripe 포털 링크 | All |
| `POST` | `/webhooks/stripe` | Stripe 웹훅 (인증 없음) | — |
| `POST` | `/webhooks/dropbox` | Dropbox 웹훅 (인증 없음) | — |

---

## 요청/응답 예시

### 규칙 생성 — `POST /rules`

```json
{
  "workflowId": "clx1234...",
  "name": "PDF 자동 분류",
  "definition": {
    "conditions": [
      { "field": "path", "op": "startsWith", "value": "/Downloads" },
      { "field": "extension", "op": "eq", "value": "pdf" }
    ],
    "conditionLogic": "AND",
    "actions": [
      {
        "type": "move",
        "destination": "/Docs/PDF/{YYYY}/{MM}",
        "onConflict": "version",
        "normalizeFilename": true
      }
    ],
    "takeSnapshot": true
  }
}
```

### Undo 응답 — `POST /jobs/:id/undo`

```json
{
  "success": true,
  "rolledBack": [
    {
      "snapshotId": "snap_abc123",
      "file": "/Downloads/report.pdf",
      "restoredFrom": "/Docs/PDF/2025/01/report.pdf"
    }
  ]
}
```

### 에러 응답 — 플랜 제한 초과

```json
{
  "error": "Plan limit reached",
  "code": "PLAN_LIMIT_EXCEEDED",
  "feature": "rulesMax",
  "upgrade": true,
  "currentPlan": "FREE",
  "requiredPlan": "PRO"
}
```
