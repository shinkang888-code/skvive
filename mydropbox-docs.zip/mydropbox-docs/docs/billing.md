# 빌링 & 플랜

## 플랜 비교

| 기능 | Free | Pro ($29/월) | Team ($99/월) |
|------|:----:|:------------:|:-------------:|
| Dropbox 연결 수 | 1 | 5 | 무제한 |
| 활성 규칙 수 | 2 | 20 | 100 |
| 일일 작업 수 | 50 | 500 | 5,000 |
| 폴더 감시 수 | 1 | 10 | 50 |
| Slack/Email 알림 | ✗ | ✓ | ✓ |
| Kakao 알림톡 | ✗ | ✗ | ✓ |
| 승인 워크플로우 | ✗ | ✗ | ✓ |
| Undo / 롤백 | ✗ | ✓ | ✓ |
| 감사 로그 내보내기 | ✗ | ✗ | ✓ |
| 멀티 시트 | 1명 | 3명 | 무제한 |
| 무료 체험 | 14일 | — | — |

---

## Stripe 연동

### 구독 생성 흐름

```
사용자 "Pro 업그레이드" 클릭
        ↓
POST /api/v1/billing/subscribe
  { priceId: "price_pro_monthly" }
        ↓
Stripe Customer 생성 (최초 1회)
        ↓
Stripe Subscription 생성
  + 14일 trial_period
        ↓
DB: Subscription 레코드 저장
    Organization.plan = PRO
```

### 웹훅으로 상태 동기화

```typescript
// Stripe 이벤트 → DB 자동 동기화
'customer.subscription.updated' → plan/status 업데이트
'customer.subscription.deleted' → plan = FREE 강등
'invoice.payment_failed'        → 관리자 알림 발송
```

---

## 플랜 강제 적용 (백엔드)

```typescript
// 미들웨어에서 플랜 한도 확인
const PLAN_LIMITS = {
  FREE:  { rulesMax: 2,   jobsPerDay: 50,   watchersMax: 1  },
  PRO:   { rulesMax: 20,  jobsPerDay: 500,  watchersMax: 10 },
  TEAM:  { rulesMax: 100, jobsPerDay: 5000, watchersMax: 50 },
};

// 규칙 생성 API에서 한도 초과 시
// HTTP 402 Payment Required 반환
{
  "error": "Plan limit reached",
  "code": "PLAN_LIMIT_EXCEEDED",
  "upgrade": true
}
```

!!! warning "중요"
    플랜 제한은 **프론트엔드 UI만으로 막아서는 안 됩니다.**
    반드시 백엔드 API에서 검증합니다.

---

## Stripe 빌링 포털

사용자가 직접 구독을 관리(플랜 변경, 결제 수단 변경, 취소)할 수 있도록
Stripe Hosted Billing Portal을 사용합니다.

```typescript
// POST /api/v1/billing/portal
const session = await stripe.billingPortal.sessions.create({
  customer: org.stripeCustomerId,
  return_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing`,
});
return { url: session.url };
```
