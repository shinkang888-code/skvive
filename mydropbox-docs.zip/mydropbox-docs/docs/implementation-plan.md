# 구현 계획

## 12주 마일스톤

### Phase 1 — 기반 (1~2주)

- [ ] Next.js 14 프로젝트 스캐폴딩
- [ ] Prisma 스키마 + PostgreSQL 마이그레이션
- [ ] NextAuth.js 세션 (이메일/비밀번호)
- [ ] Organization/Membership 모델
- [ ] 기본 대시보드 UI 쉘

### Phase 2 — Dropbox OAuth (3주)

- [ ] OAuth 2.0 PKCE 흐름 구현
- [ ] AES-256-GCM 토큰 암호화
- [ ] 연결 관리 UI (추가/삭제/라벨)
- [ ] 멀티 계정 지원

### Phase 3 — 파일 기능 (4주)

- [ ] 파일 검색 UI + API
- [ ] 폴더 생성 / 이름 변경 / 이동
- [ ] 모든 작업에 Snapshot + AuditLog 적용

### Phase 4 — 워크플로우 엔진 (5~6주)

- [ ] BullMQ + Redis 셋업
- [ ] Rule DSL 파서 + 실행기
- [ ] 조건 평가 (조건 연산자 전체)
- [ ] 경로 템플릿 렌더러 (`{YYYY}`, `{MM}` 등)
- [ ] 충돌 처리 (overwrite/version/skip)
- [ ] 규칙 생성 UI

### Phase 5 — 고급 워크플로우 (7~8주)

- [ ] 일괄 이름 변경 / 이동 / 폴더 생성
- [ ] 승인 워크플로우 (ToReview → Approved/Rejected)
- [ ] Undo / 롤백 기능
- [ ] Soft Delete (`/Archive/Trash/`)
- [ ] 스케줄 트리거 (Cron)

### Phase 6 — 알림 (9주)

- [ ] Slack Webhook 연동
- [ ] Email (Resend) 연동
- [ ] Kakao 알림톡 연동
- [ ] 폴더 감시 (Longpoll + Webhook)

### Phase 7 — 빌링 (10주)

- [ ] Stripe 구독 연동
- [ ] 플랜 강제 미들웨어
- [ ] 사용량 미터링
- [ ] Stripe Webhook 동기화
- [ ] 빌링 포털 연동

### Phase 8 — 완성 (11~12주)

- [ ] 감사 로그 CSV 내보내기
- [ ] 보안 강화 (CSP, Rate Limit, 서명 검증)
- [ ] Docker 프로덕션 빌드
- [ ] E2E 테스트 (Playwright)
- [ ] 로드 테스트

---

## 테스트 전략

### 단위 테스트 (Jest)

```
- encryptToken / decryptToken 왕복 테스트
- evaluateConditions DSL — 전체 연산자
- renderTemplate — 날짜 토큰, 버전 충돌
- buildAuthUrl — PKCE 파라미터 검증
```

### 통합 테스트

```
- OAuth 콜백 → 토큰 DB 암호화 저장
- 규칙 실행 → 파일 이동 (Dropbox API mock)
- Undo → 원본 경로 복원
- Stripe 웹훅 → 구독 상태 DB 업데이트
```

### E2E 테스트 (Playwright)

```
1. 회원가입 → Dropbox 연결 → 규칙 생성
   → 수동 실행 → 감사 로그 확인

2. 파일 업로드 → 승인 요청 → 승인 처리
   → /Shared/Approved 이동 확인

3. Pro 구독 → 규칙 한도 증가 확인
```

---

## 환경변수 체크리스트

```bash
# 필수 (개발)
DATABASE_URL=
REDIS_HOST=
DROPBOX_APP_KEY=
DROPBOX_APP_SECRET=
DROPBOX_REDIRECT_URI=
TOKEN_ENCRYPTION_KEY=    # openssl rand -hex 32
NEXTAUTH_SECRET=

# 필수 (프로덕션 추가)
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
STRIPE_PRO_PRICE_ID=
STRIPE_TEAM_PRICE_ID=

# 선택 (알림)
SLACK_WEBHOOK_URL=
RESEND_API_KEY=
KAKAO_API_KEY=
```
