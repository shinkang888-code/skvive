# Dropbox OAuth & 토큰 관리

## OAuth 2.0 PKCE 흐름

```
사용자 클릭 "Dropbox 연결"
        ↓
GET /api/v1/auth/dropbox/connect
  → codeVerifier 생성 (세션 저장)
  → codeChallenge = SHA-256(codeVerifier)
  → Dropbox 인증 페이지로 리다이렉트
        ↓
사용자가 Dropbox에서 권한 허가
        ↓
GET /api/v1/auth/dropbox/callback?code=...&state=...
  → state 검증 (CSRF 방지)
  → code + codeVerifier 로 access/refresh token 교환
  → refresh_token AES-256-GCM 암호화
  → DB 저장 (DropboxConnection)
        ↓
연결 완료 ✓
```

---

## 필수 OAuth 스코프

| 스코프 | 용도 |
|--------|------|
| `files.content.read` | 파일 내용 읽기 |
| `files.content.write` | 파일 내용 쓰기 |
| `files.metadata.read` | 파일 메타데이터 조회 |
| `files.metadata.write` | 파일 이동/이름 변경 |
| `account_info.read` | 계정 정보 (이메일 표시용) |

---

## 토큰 암호화 (AES-256-GCM)

```typescript
// src/lib/dropbox/crypto.ts
import { createCipheriv, createDecipheriv, randomBytes } from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const KEY = Buffer.from(process.env.TOKEN_ENCRYPTION_KEY!, 'hex'); // 32 bytes

export function encryptToken(plaintext: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv(ALGORITHM, KEY, iv);
  const encrypted = Buffer.concat([
    cipher.update(plaintext, 'utf8'),
    cipher.final()
  ]);
  const tag = cipher.getAuthTag();
  // 저장 형식: iv:tag:ciphertext (모두 hex)
  return [iv.toString('hex'), tag.toString('hex'), encrypted.toString('hex')].join(':');
}

export function decryptToken(stored: string): string {
  const [ivHex, tagHex, encHex] = stored.split(':');
  const decipher = createDecipheriv(ALGORITHM, KEY, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  return decipher.update(Buffer.from(encHex, 'hex')) + decipher.final('utf8');
}
```

!!! tip "마스터 키 생성"
    ```bash
    openssl rand -hex 32
    # 출력값을 TOKEN_ENCRYPTION_KEY 환경변수에 설정
    ```

---

## 자동 토큰 갱신

Access Token은 **4시간** 후 만료됩니다.
만료 **5분 전**에 자동으로 갱신합니다.

```typescript
// src/lib/dropbox/client.ts
export async function getValidAccessToken(connectionId: string) {
  const conn = await prisma.dropboxConnection.findUniqueOrThrow({
    where: { id: connectionId }
  });

  const BUFFER_MS = 5 * 60 * 1000; // 5분 여유
  const now = Date.now();

  // 캐시된 토큰이 유효하면 그대로 사용
  if (
    conn.encryptedAccessToken &&
    conn.accessTokenExpiresAt &&
    conn.accessTokenExpiresAt.getTime() - now > BUFFER_MS
  ) {
    return decryptToken(conn.encryptedAccessToken);
  }

  // Refresh Token으로 새 Access Token 발급
  const { access_token, expires_in } = await refreshAccessToken(
    conn.encryptedRefreshToken
  );

  // DB 업데이트
  await prisma.dropboxConnection.update({
    where: { id: connectionId },
    data: {
      encryptedAccessToken: encryptToken(access_token),
      accessTokenExpiresAt: new Date(now + expires_in * 1000),
    }
  });

  return access_token;
}
```

---

## 멀티 계정 지원

하나의 조직이 여러 Dropbox 계정을 연결할 수 있습니다.

| 계정 유형 | 지원 |
|-----------|------|
| Personal Dropbox | ✓ |
| Dropbox Business | ✓ |
| 여러 계정 동시 연결 | ✓ (Pro: 5개, Team: 무제한) |

각 연결은 `label` 필드로 구분합니다 (예: "업무용", "개인용").
